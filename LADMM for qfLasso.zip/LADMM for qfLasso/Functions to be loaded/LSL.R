LSL=function(x,mu,tau){
  u=rep(0,length(x))
  for(i in 1:length(x)){
   if(x[i]>=0){u[i]=n*mu*x[i]/(n*mu+2*tau)}else{
    u[i]=n*mu*x[i]/(n*mu+2*(1-tau))}
  }
  return(u)
}