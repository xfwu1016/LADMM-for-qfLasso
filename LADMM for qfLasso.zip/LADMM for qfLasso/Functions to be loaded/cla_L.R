cla_L=function(y,X,lambda1,lambda2,tau){
n=nrow(X)
p=ncol(X)
mu<-0.1#1�Ը�ά
#gam=matrix(1,ncol=1,nrow=n)

hXX=rbind(cbind(mu*n,mu*t(gam)%*%X),cbind(mu*t(X)%*%gam,mu*t(X)%*%X+mu*FTF(p)))
######
ite=2000
#
eta=pmethod(A=hXX,x=rep(1,ncol(hXX)),ite=1000)[1]
eta=0.76*eta+0.05
#update beta
beta0<-rep(0,p+1)
b0=rep(0,p-1)
r0=y-X%*%beta0[2:(p+1)]
v0=rep(0.000,n)
w0=rep(0,p-1)

beta_M<-matrix(0.000,p+1,ite+1)
b_M<-matrix(0.000,p-1,ite+1)
r_M<-matrix(0.000,n,ite+1)
v_M<-matrix(0.000,n,ite+1)
w_M<-matrix(0.000,p-1,ite+1)

beta_M[,1]=beta0
b_M[,1]=b0
r_M[,1]=r0
v_M[,1]=v0
w_M[,1]=w0
#��¼�в�
pri=rep(0,ite+1)
dua=rep(0,ite+1)
#
k=0
repeat{
  #ԭ��������
  fk1=mu*t(gam)%*%(gam*beta_M[,k+1][1]+X%*%beta_M[,k+1][2:(p+1)]
                   -y+r_M[,k+1]+v_M[,k+1]/mu)
  fk2=mu*t(F)%*%(F%*%beta_M[,k+1][2:(p+1)]-b_M[,k+1]-w_M[,k+1]/mu)+mu*t(X)%*%(
    gam*beta_M[,k+1][1]+X%*%beta_M[,k+1][2:(p+1)]-y+r_M[,k+1]+v_M[,k+1]/mu)
  beta0_u=as.numeric(beta_M[,k+1][1]-fk1/eta)
  beta_u=Thld(beta_M[,k+1][2:(p+1)]-fk2/eta,lambda1,eta)
  b_u=Thld(F%*%beta_u-w_M[,k+1]/mu,lambda2,mu)
  r_u=PL(y-X%*%beta_u-beta0_u*gam-v_M[,k+1]/mu,mu)
  #��ż��������
  v_u=v_M[,k+1]-mu*(y-X%*%beta_u-beta0_u*gam-r_u)
  w_u=w_M[,k+1]-mu*(F%*%beta_u-b_u)
  
  
  
  #k+1����
  k=k+1
  beta_M[,k+1]= c(beta0_u,beta_u)
  b_M[,k+1]=b_u
  r_M[,k+1]=r_u
  v_M[,k+1]=v_u
  w_M[,k+1]=w_u
  #
  pri[k]=mu*sqrt(sum((t(gam)%*%(r_M[,k]-r_M[,k+1]))^2)+
                   sum((t(X)%*%(r_M[,k]-r_M[,k+1])+t(F)%*%(b_M[,k+1]-b_M[,k]))^2))
  dua[k]=sqrt(sum((gam*beta0_u+X%*%beta_u+r_u-y)^2)+sum((F%*%beta_u-b_u)^2))
  if(10*pri[k]<dua[k]){
    t=2
  }else if(pri[k]>10*dua[k]){
    t=1/2
  }else{t=1}
  mu=t*mu
  err=10^-3
  con1=sqrt(p)*err+err*sqrt(sum((t(gam)%*%v_u)^2)+sum((t(X)%*%v_u+
                                                         t(F)%*%w_u)^2))
  dd1=sum((gam*beta0_u+X%*%beta_u)^2)+sum((F%*%beta_u)^2)
  dd2=sum((r_u)^2)+sum((b_u)^2)
  con2=sqrt(n)*err+err*sqrt(max(dd1,dd2,sum(y^2)))
  
  #
  if(((pri[k]<con1)&(dua[k]<con2))|(k>ite-1)){
    break
  }
}
result=list(beta0= beta0_u,beta_u=beta_u,K=k,pri=pri,dua=dua)
return(result)
}