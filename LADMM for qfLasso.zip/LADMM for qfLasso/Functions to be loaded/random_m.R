random_m<-function(n,p,beta)
{
  rho <- 0.1 #���Ե���0.2,0.4,0.6
  R <- matrix(0,p,p)#
  for(i in 1:p){
    for(j in 1:p){
      R[i,j] <- rho^abs(i-j)
    }
  }
  error=0.9*rnorm(n,0,1)+0.1*rnorm(n,0,25) 
  X <- matrix(rnorm(n*p),n,p) %*% t(chol(R))#ͨ��chol��ʽ��֤����xi��xj�Ĺ�ϵ
  #M<-cbind(M,rep(1,n))
  delte=0.5#0.5,1.5
  y <- X %*% beta + delte*error
  result<-list(X=X,y=y)
  return(result)
}
