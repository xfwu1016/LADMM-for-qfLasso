library(flsa)
library(flsa)#package flsa
source("pmethod.R") #the power method
source("Thld.R")#Soft threshold operator
source("PL.R")#pinball loss operator
source("LSL.R")# least squares  operator
source("FLSA_L.R") #FLSA 
source("qFLSA_L.R") #qFLSA

load("CGH.rda")
str(CGH)
data<-CGH$GBM.y
y<-rep(data,3)[1:250]
p<-length(y)
plot(y,xlab="Genome Order",ylab="log2(Ratio)")
write.table(y,file = "y")
median(y)
quantile(y,0.35)

F_matrix<-function(p)
{
  F=matrix(0,p-1,p)
  for(i in 1:(p-1))
  {
    F[i,i]=1
    F[i,i+1]=-1
  }
  return(F)
}
F=F_matrix(p)
FTF=function(p){
  if(p==2){FTF=matrix(c(1,-1,-1,1),2,2)}else{
    FTF=matrix(0,p,p)
    F1 = diag(p)*0
    diag(F1[-1,-p]) = -1
    F2=t(F1)
    F3=diag(c(rep(2,p-1),1),p)
    FTF=F1+F2+F3}
  return(FTF)
}
####qFLSA
tau=2.5
start<-Sys.time()
qFLSA=qFLSA_L(y,lambda1=0.00002,lambda2=0.002,tau)
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
qFLSA$K
qbeta_r=qFLSA$beta_u
length(which(abs(qbeta_r)>10^-5))#the number of nonzero
#plot(y)
plot(qbeta_r,type = "l")

write.table(qbeta_r,file = "qbeta")


#######FLSA
#flsa package
flsa=flsa(y,lambda1=0.0001,lambda2=0.1)
plot(flsa,type="l")

write.table(flsa,file = "flsa")

#ADMM
start<-Sys.time()
FLSA=FLSA_L(y,lambda1=0.00001,lambda2=0.001)
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
FLSA$K
beta_r=FLSA$beta_u
length(which(abs(beta_r)>10^-5))#the number of nonzero
plot(beta_r,type = "l")
write.table(beta_r,file = "beta")
