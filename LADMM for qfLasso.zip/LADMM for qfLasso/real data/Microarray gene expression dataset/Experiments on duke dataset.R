source("pmethod.R") #the power method
source("Thld.R") #Soft threshold operator
source("PL.R") #pinball loss operator
source("cla_L.R") #qfSVM
source("FLSVM_L.R") #FL-SVM
source("HL.R") #hinge loss #pinball loss operator


duke=read.table("duke.txt",head=FALSE)
str(duke)
y_label=duke$V1
X0=matrix(0,nrow = 44,ncol =7129)
Y=diag(y_label)
for(i in 1:44){
  for(j in 1:7129){
    X0[i,j]=as.numeric(strsplit(as.character(duke[,(j+1)]),":")[[i]][2])
  }
}  
str(X0)

y=rep(1,length(y_label))
X=Y%*%X0


###Training set
set.seed(666)
tr=sample(1:44,22)
y_tr=y[tr]
X_tr=X[tr,]
gam=(diag(y_label)%*%matrix(1,nrow=length(y),ncol=1))[tr]

###Test set
y_te=y_label[-tr]
X_te=X0[-tr,]

###
p=7129
F_matrix<-function(p)
{
  F=matrix(0,p-1,p)
  for(i in 1:(p-1))
  {
    F[i,i]=1
    F[i,i+1]=-1
  }
  return(F)
}
F=F_matrix(p)
#
FTF=function(p){
  FTF=matrix(0,p,p)
  F1 = diag(p)*0
  diag(F1[-1,-p]) = -1
  F2=t(F1)
  F3=diag(c(rep(2,p-1),1),p)
  FTF=F1+F2+F3
  return(FTF)
}
#
###############qfSVM
#LADMM
start<-Sys.time()
qfSVM=cla_L(y_tr,X_tr,lambda1=0.005,lambda2=0.05,tau)#0.2,,0.25
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
qfSVM$K
beta_c=qfSVM$beta_u
length(which(abs(beta_c)>10^-6))#the number of nonzero
beta_0=qfSVM$beta0
length(which(sign(X_te%*%beta_c+beta_0)-y_te==0))/(22)
plot(qfSVM$pri[1:qfSVM$K])
plot(qfSVM$dua[1:qfSVM$K])


