source("pmethod.R") #the power method
source("Thld.R") #Soft threshold operator
source("PL.R") #pinball loss operator
source("cla_L.R") #qfSVM
source("FLSVM_L.R") #FL-SVM
source("HL.R") #hinge loss #pinball loss operator




leu=read.table("leu.txt",head=FALSE)
str(leu)
y_label=leu$V1
Y=diag(y_label)
X0=matrix(0,nrow = 38,ncol =7129)
for(i in 1:38){
  for(j in 1:7129){
    X0[i,j]=as.numeric(strsplit(leu[,(j+1)],":")[[i]][2])
  }
}  
str(X0)
y=rep(1,length(y_label))
X=Y%*%X0
gam=diag(y_label)%*%matrix(1,nrow=length(y),ncol=1)


#####test
leut=read.table("leut.txt",head=FALSE)
str(leut)
y_labelt=leut$V1
X0t=matrix(0,nrow = 34,ncol =7129)
for(i in 1:34){
  for(j in 1:7129){
    X0t[i,j]=as.numeric(strsplit(leut[,(j+1)],":")[[i]][2])
  }
}  
str(X0t)

###
p=7129
F_matrix<-function(p)
{
  F=matrix(0,p-1,p)
  for(i in 1:(p-1))
  {
    F[i,i]=1
    F[i,i+1]=-1
  }
  return(F)
}
F=F_matrix(p)
#
FTF=function(p){
  FTF=matrix(0,p,p)
  F1 = diag(p)*0
  diag(F1[-1,-p]) = -1
  F2=t(F1)
  F3=diag(c(rep(2,p-1),1),p)
  FTF=F1+F2+F3
  return(FTF)
}
#
###############qfSVM
#LADMM
start<-Sys.time()
qfSVM=cla_L(y,X,lambda1=0.02,lambda2=0.5)#0.2,,0.25
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
qfSVM$K
beta_c=qfSVM$beta_u
length(which(abs(beta_c)>10^-6))#the number of nonzero
beta_0=qfSVM$beta0
length(which(sign(X0%*%beta_c+beta_0)-y_label==0))/38
length(which(sign(X0t%*%beta_c+beta_0)-y_labelt==0))/34
plot(qfSVM$pri[1:qfSVM$K])
plot(qfSVM$dua[1:qfSVM$K])


