source("pmethod.R") #the power method
source("Thld.R") #Soft threshold operator
source("PL.R")#pinball loss operator
source("cla_L.R")#qfSVM
source("FLSVM_L.R")#fused Lasso SVM
source("HL.R") #hinge loss operator

set.seed(123)
#####data
n=500
#��һ��
X11 <- matrix(rnorm(n,0.5,0.2), n, 1)
X12 <- matrix(rnorm(n,-3,3), n, 1)
X1=cbind(X11,X12)
#�ڶ���
X21 <- matrix(rnorm(n,-0.5,0.2), n, 1)
X22 <- matrix(rnorm(n,3,3), n, 1)
X2=cbind(X21,X22)

X0=rbind(X1,X2)
plot(X0)
lines(c(-3:3),6.11*c(-3:3),main="test",type="l",xlim=c(-2,2),ylim=c(-8,8))
y_label=c(rep(1,n),rep(-1,n))
Y=diag(y_label)
X=Y%*%X0
y=rep(1,length(y_label))
gam=diag(y_label)%*%matrix(1,nrow=length(y),ncol=1)



#####
F_matrix<-function(p)
{
  F=matrix(0,p-1,p)
  for(i in 1:(p-1))
  {
    F[i,i]=1
    F[i,i+1]=-1
  }
  return(F)
}
F=F_matrix(2)
#
FTF=function(p){
  if(p==2){FTF=matrix(c(1,-1,-1,1),2,2)}else{
    FTF=matrix(0,p,p)
    F1 = diag(p)*0
    diag(F1[-1,-p]) = -1
    F2=t(F1)
    F3=diag(c(rep(2,p-1),1),p)
    FTF=F1+F2+F3}
  return(FTF)
}
FTF(2)

#


##############cla
#LADMM for qfSVM #mu need to be 0.01
start<-Sys.time()
tau=0.1
cla=cla_L(y,X,lambda1=0.01,lambda2=0.1,tau)#0.15,0.195,0.18,0.165,0.275,0.68,0.65
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
cla$K #Number of iterations
beta_c=cla$beta_u 
beta_c
-(beta_c[2]/beta_c[1])#beta1
beta_0=cla$beta0
beta_0
(beta_0/beta_c[1])#beta0
length(which(sign(X0%*%beta_c+beta_0)-y_label==0))/(2*n) #Classification accuracy


plot(cla$pri[1:cla$K])
plot(cla$dua[1:cla$K])



