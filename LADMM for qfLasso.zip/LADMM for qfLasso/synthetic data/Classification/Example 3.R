source("pmethod.R") #the power method
source("Thld.R") #Soft threshold operator
source("PL.R")#pinball loss operator
source("cla_L.R")#qfSVM
source("FLSVM_L.R")#fused Lasso SVM
source("HL.R") #hinge loss operator

library(MASS) #����MASS��
n=50
p=1000
q=10
rho <- 0.5 #���Ե���0.2,0.4,0.6 correlation coefficient
eta=0.1 #0.1,0.2,0.4 noise level
#noise
mean<-rep(0,p) #ָ����ֵ����
si=matrix(0.8,ncol=10,nrow = 10)
si=si+diag(0.2,10)
sigma=diag(1,p)
sigma[1:10,1:10]=si #ָ��Э�������
X_noise <- mvrnorm(2*eta*n, mean, sigma) 
#��һ��
x1 <- matrix(rnorm(n*q,0,1), n, q)
x2 <- matrix(rnorm(n*(p-q),0,1), n, p-q)

corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_1 <- cbind(x1%*% chol(corrmat1)+1, x2%*% chol(corrmat2))
X_1[1:(eta*n)]=X_noise[1:(eta*n)]
#�ڶ���
x1 <- matrix(rnorm(n*q,0,1), n, q)
x2 <- matrix(rnorm(n*(p-q),0,1), n, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_2 <- cbind(x1%*% chol(corrmat1)-1, x2%*% chol(corrmat2))
X_2[1:(eta*n)]=X_noise[(eta*n+1):(2*eta*n)]
########����׼��
X0=rbind(X_1,X_2)
y_label=c(rep(1,n),rep(-1,n))
Y=diag(y_label)
X=Y%*%X0
y=rep(1,length(y_label))
gam=diag(y_label)%*%matrix(1,nrow=length(y),ncol=1)
###test data
nt=500
#��һ��
x1 <- matrix(rnorm(nt*q,0,1), nt, q)
x2 <- matrix(rnorm(nt*(p-q),0,1), nt, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_1 <- cbind(x1%*% chol(corrmat1)+1, x2%*% chol(corrmat2))
#�ڶ���
x1 <- matrix(rnorm(nt*q,0,1), nt, q)
x2 <- matrix(rnorm(nt*(p-q),0,1), nt, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_2 <- cbind(x1%*% chol(corrmat1)-1, x2%*% chol(corrmat2))
#
X0t=rbind(X_1,X_2)
yt_label=c(rep(1,nt),rep(-1,nt))
#
F_matrix<-function(p)
{
  F=matrix(0,p-1,p)
  for(i in 1:(p-1))
  {
    F[i,i]=1
    F[i,i+1]=-1
  }
  return(F)
}
F=F_matrix(p)
#
FTF=function(p){
  FTF=matrix(0,p,p)
  F1 = diag(p)*0
  diag(F1[-1,-p]) = -1
  F2=t(F1)
  F3=diag(c(rep(2,p-1),1),p)
  FTF=F1+F2+F3
  return(FTF)
}
#



##############qfSVM
#LADMM # mu need to be 1
start<-Sys.time()
tau=1
qfSVM=cla_L(y,X,lambda1=0.2,lambda2=0.1,tau)#0.2,,0.25
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
qfSVM$K #Number of iterations
beta_c=qfSVM$beta_u
length(which(abs(beta_c)>10^-5))#the number of nonzero
beta_0=qfSVM$beta0
length(which(sign(X0%*%beta_c+beta_0)-y_label==0))/(2*n)
length(which(sign(X0t%*%beta_c+beta_0)-yt_label==0))/(2*nt)
plot(qfSVM$pri[1:PFLSVM$K])
plot(qfSVM$dua[1:PFLSVM$K])

beta_0/beta_c[1]#beta0
beta_c[1:q]/median(beta_c[1:q]) #beta

##############FLSVM
start<-Sys.time()
FLSVM=FLSVM_L(y,X,lambda1=0.85,lambda2=0.5)#0.2,,0.25
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
FLSVM$K
beta_c=FLSVM$beta_u
length(which(abs(beta_c)>10^-5))#the number of nonzero
beta_0=FLSVM$beta0
length(which(sign(X0%*%beta_c+beta_0)-y_label==0))/(2*n)
length(which(sign(X0t%*%beta_c+beta_0)-yt_label==0))/(2*nt)
plot(FLSVM$pri[1:FLSVM$K])
plot(FLSVM$dua[1:FLSVM$K])

beta_0/beta_c[1]
beta_c[1:q]/median(beta_c[1:q])
