source("random_t.R") #t error
source("random_c.R") #cauchy error
source("random_n.R") #norm error
source("random_m.R") #mixed norm error
source("pmethod.R") #the power method
source("Thld.R") #Soft threshold operator
source("PL.R") #pinball loss operator
source("reg_L.R") #qfLasso

#####data for regression 
###### mu need to be 0.01
n=720
p=2560
set.seed(66666)
index=1:80
ind=sample(index,10)
beta=rep(0,p)
for (i in 1:10) {
  beta[((ind[i]-1)*32+1):((ind[i]-1)*32+32)]=rep(runif(1,-3,3),32)
}
plot(beta)

rand=random_c(n,p,beta)
y=rand$y
X=rand$X
X=scale(X,center=FALSE,scale=T)
#X=diag(y)%*%X
gam=matrix(1,nrow=n,ncol=1)#�����ع�ͷ����,diag(y)%*%matrix(1,nrow=n,ncol=1)

F_matrix<-function(p)
{
  F=matrix(0,p-1,p)
  for(i in 1:(p-1))
  {
    F[i,i]=1
    F[i,i+1]=-1
  }
  return(F)
}
F=F_matrix(p)
#
FTF=function(p){
  FTF=matrix(0,p,p)
  F1 = diag(p)*0
  diag(F1[-1,-p]) = -1
  F2=t(F1)
  F3=diag(c(rep(2,p-1),1),p)
  FTF=F1+F2+F3
  return(FTF)
}
#
#lambda1=0.05
#lambda2=0.1
tau=1

##############reg
#LADMM
start<-Sys.time()
reg=reg_L(y,X,lambda1=0.01,lambda2=0.2,tau)#0.01,0.1
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
beta_r=reg$beta_u
length(which(abs(beta_r)>10^-5))#the number of nonzero
beta_0=reg$beta0

sqrt(sum((y-X%*%beta_r-beta_0)^2))/n
plot(reg$pri[1:reg$K])
plot(reg$dua[1:reg$K])

plot(beta)
plot(beta_r)
### i in G
dd1=rep(0,320)
for (i in 1:10) {
  dd1[((i-1)*32+1):(32*i)]=abs(beta[((ind[i]-1)*32+1):((ind[i]-1)*32+32)]-
                                 beta_r[((ind[i]-1)*32+1):((ind[i]-1)*32+32)])
}
length(which(dd1<0.1))
max(dd1)

### in in G^c
dd2=rep(0,2240)
ind2=index[-ind]
for (i in 1:70) {
  dd2[(32*(i-1)+1):(32*i)]=abs(beta_r[((ind2[i]-1)*32+1):((ind2[i]-1)*32+32)])
  
}
length(which(dd2<0.1))
max(dd2)

