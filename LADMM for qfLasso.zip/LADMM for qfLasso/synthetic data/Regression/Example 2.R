library(flsa)#package flsa
source("pmethod.R") #the power method
source("Thld.R")#Soft threshold operator
source("PL.R")#pinball loss operator
source("LSL.R")# least squares  operator
source("FLSA_L.R") #FLSA 
source("qFLSA_L.R") #qFLSA
#######mu need to be 0.01
set.seed(1234)
p=300
y<-c(rep(0,47),rep(-2.5,5),rep(0,48),rep(-2.5,5),rep(0,10),rep(2.5,10),rep(0,60),rep(3.7,30),rep(0,85))
#y=y+0.2*rt(p,1.5)#123
y=y+0.2*rcauchy(p)#1234
plot(y,type="l")
#write.table(y,file = "y")
#####
F_matrix<-function(p)
{
  F=matrix(0,p-1,p)
  for(i in 1:(p-1))
  {
    F[i,i]=1
    F[i,i+1]=-1
  }
  return(F)
}
F=F_matrix(p)
#
FTF=function(p){
  if(p==2){FTF=matrix(c(1,-1,-1,1),2,2)}else{
    FTF=matrix(0,p,p)
    F1 = diag(p)*0
    diag(F1[-1,-p]) = -1
    F2=t(F1)
    F3=diag(c(rep(2,p-1),1),p)
    FTF=F1+F2+F3}
  return(FTF)
}
FTF(2)

#


plot(y,type="l")
median(y)


####qFLSA##mu=0.01
start<-Sys.time()
tau=1
qFLSA=qFLSA_L(y,lambda1=0.0005,lambda2=0.002,tau)
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
qbeta_r=qFLSA$beta_u
length(which(abs(qbeta_r)>10^-5))#the number of nonzero
plot(qbeta_r,type = "l")


beta_r[48:52]
y[48:52]
beta_r[101:105]
y[101:105]
beta_r[116:125]
y[116:125]
beta_r[186:215]
y[186:215]

#######FLSA
#flsa package
flsa=flsa(y,lambda1=0.05,lambda2=0.2)
plot(flsa,type="l")
write.table(flsa,file = "flsa_c")
flsa[48:52]
flsa[101:105]
flsa[116:125]
flsa[186:215]

#ADMM
start<-Sys.time()
FLSA=FLSA_L(y,lambda1=0.0005,lambda2=0.002)
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
beta_r=FLSA$beta_u
length(which(abs(beta_r)>10^-5))#the number of nonzero
plot(beta_r,type = "l")

